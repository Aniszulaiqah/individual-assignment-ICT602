package com.example.electricitybillestimator;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about); // Make sure the layout is correctly referenced

        // Set up the content for the About page
        TextView tvAboutDetails = findViewById(R.id.tvAboutDetails);
        TextView tvAppWebsite = findViewById(R.id.tvAppWebsite);

        // Set developer and app details
        tvAboutDetails.setText(
                "Developed by: ANIS ZULAIQAH\n" +
                        "Email: zulaiqahanis@gmail.com\n" +
                        "Version: 1.0.0\n\n" +
                        "Copyright © 2024 Electricity Bill Estimator"
        );

        // Set up the clickable URL
        tvAppWebsite.setText("Visit My Website");
        tvAppWebsite.setOnClickListener(v -> {
            // Open the website URL
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/Aniszulaiqah"));
            startActivity(browserIntent);
        });
    }
}
