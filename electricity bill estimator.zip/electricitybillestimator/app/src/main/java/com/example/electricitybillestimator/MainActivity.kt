package com.example.electricitybillestimator

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.electricitybillestimator.ui.theme.ElectricityBillEstimatorTheme
import java.util.Locale // Import added here

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Set up view references for Compose UI
        setContent {
            ElectricityBillEstimatorTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    // Place other composables here
                    Greeting(
                        name = "Electricity Bill Estimator",
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }

        enableEdgeToEdge()

        // Set up view references for XML-based UI
        setContentView(R.layout.activity_main)

        val etUnits = findViewById<EditText>(R.id.etUnits)
        val etRebate = findViewById<EditText>(R.id.etRebate)
        val btnCalculate = findViewById<Button>(R.id.btnCalculate)
        val tvResult = findViewById<TextView>(R.id.tvResult)
        val btnAbout = findViewById<Button>(R.id.btnAbout)

        // Set OnClickListener to navigate to AboutActivity
        btnAbout.setOnClickListener {
            val intent = Intent(this, AboutActivity::class.java)
            startActivity(intent)
        }

        // Set OnClickListener to calculate the electricity bill
        btnCalculate.setOnClickListener {
            val unitsUsed = etUnits.text.toString().toDoubleOrNull()
            val rebatePercentage = etRebate.text.toString().toDoubleOrNull()

            if (unitsUsed == null || rebatePercentage == null || rebatePercentage < 0 || rebatePercentage > 100) {
                tvResult.text = "Please enter valid inputs."
                return@setOnClickListener
            }

            val totalCharges = calculateBill(unitsUsed)
            val rebateAmount = totalCharges * (rebatePercentage / 100)
            val finalCost = totalCharges - rebateAmount

            // Fixed ambiguity with explicit Locale usage
            tvResult.text = String.format(
                Locale.getDefault(),
                "Total Charges: RM%.2f\nFinal Cost (after rebate): RM%.2f",
                totalCharges,
                finalCost
            )
        }
    }

    private fun calculateBill(units: Double): Double {
        var remainingUnits = units
        var totalCost = 0.0

        // Block rates
        val firstBlockRate = 0.218
        val secondBlockRate = 0.334
        val thirdBlockRate = 0.516
        val fourthBlockRate = 0.546

        // Calculate for first 200 kWh
        if (remainingUnits > 200) {
            totalCost += 200 * firstBlockRate
            remainingUnits -= 200
        } else {
            totalCost += remainingUnits * firstBlockRate
            return totalCost
        }

        // Calculate for next 100 kWh
        if (remainingUnits > 100) {
            totalCost += 100 * secondBlockRate
            remainingUnits -= 100
        } else {
            totalCost += remainingUnits * secondBlockRate
            return totalCost
        }

        // Calculate for next 300 kWh
        if (remainingUnits > 300) {
            totalCost += 300 * thirdBlockRate
            remainingUnits -= 300
        } else {
            totalCost += remainingUnits * thirdBlockRate
            return totalCost
        }

        // Calculate for remaining units
        totalCost += remainingUnits * fourthBlockRate

        return totalCost
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Welcome to $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    ElectricityBillEstimatorTheme {
        Greeting("Electricity Bill Estimator")
    }
}
